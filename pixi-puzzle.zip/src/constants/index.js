export const pieceArray = [];
export const tempState = { avaiable: false, piece: null };
export const mousePosition = { x: null, y: null };
